import { Component } from '@angular/core';

@Component({
  selector: 'app-root', //where to inject
  template: '<h2>{{title}}</h2>',//where to display
  templateUrl: './app.component.html',//where to display
    
  styleUrls: ['./app.component.css']//how to display
})
export class AppComponent {
  title = 'Welcome To Angular 11';//what to display
}
