import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpressCRUDComponent } from './express-crud.component';

describe('ExpressCRUDComponent', () => {
  let component: ExpressCRUDComponent;
  let fixture: ComponentFixture<ExpressCRUDComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExpressCRUDComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpressCRUDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
