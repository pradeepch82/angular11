import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../services/posts.service';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {


  title='All Posts';

  posts:any;

  message='';


 userId=0; 

  constructor(private ps:PostsService,private route:ActivatedRoute) {
    console.log("============PostsComponent created======")
   }

  ngOnInit(): void {
    console.log("============PostsComponent initialized======")
    

    this.userId=this.route.snapshot.queryParams.userId;
    
    console.log("============PostsComponent initialized======"+this.userId);
    
    if(this.userId)
    this.getAllPostsByUserId();
    else
    this.getAllPosts();
  }

  ngOnDestroy(): void {
    console.log("============PostsComponent destroyed======")
    
  }




  getAllPosts(){
     this.ps.getAllPosts().subscribe(response=>this.posts=response,error=>this.message=error);
  }

  getAllPostsByUserId(){
    this.ps.getPostsByUserId(this.userId).subscribe(response=>this.posts=response,error=>this.message=error);
 }

}
