import { TestBed } from '@angular/core/testing';

import { AgeService } from './age.service';

describe('AgeService', () => {
  let service: AgeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AgeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('Test age with within range', () => {
    expect(service.validateAge(40)).toEqual(true);
  });

  it('Test age with lower boundry', () => {
    expect(service.validateAge(21)).toEqual(true);
  });

  it('Test age with upper boundry', () => {
    expect(service.validateAge(60)).toEqual(true);
  });


  it('Test age with below lower boundry', () => {
    expect(service.validateAge(12)).toEqual(false);
  });

  it('Test age with above upper boundry', () => {
    expect(service.validateAge(67)).toEqual(false);
  });
 
  

});
