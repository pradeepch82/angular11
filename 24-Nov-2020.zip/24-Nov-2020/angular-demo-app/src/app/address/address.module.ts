import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CityComponent } from './city/city.component';
import { StateComponent } from './state/state.component';
import { CountryComponent } from './country/country.component';



@NgModule({
  declarations: [CityComponent, StateComponent, CountryComponent],
  imports: [
    CommonModule
  ]
})
export class AddressModule { 

  constructor(){
    console.log("$$$$$$$$$$$$$$ AddressModule  created $$$$$$$$$$$$$")
  }

}
