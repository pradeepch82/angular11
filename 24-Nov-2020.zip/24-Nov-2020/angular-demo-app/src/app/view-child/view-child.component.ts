import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { BgColorDirective } from '../directives/bg-color.directive';
import { NumberComponent } from '../number/number.component';

@Component({
  selector: 'app-view-child',
  templateUrl: './view-child.component.html',
  styleUrls: ['./view-child.component.css']
})
export class ViewChildComponent implements OnInit {



  @ViewChild(NumberComponent,{static:false})
  private n:NumberComponent;

  @ViewChild(BgColorDirective,{static:false})
  private b:BgColorDirective;


  @ViewChild("name",{static:false}) 
  private name:ElementRef;
  
  @ViewChild("city",{static:false}) 
  private city:ElementRef;
  

  @ViewChild("e",{static:false}) 
  private e:ElementRef;
  


  constructor() { }

  ngOnInit(): void {
  }


  increase(){
   this.n.increaseNumber();
  }
  
  decrease(){
this.n.decreaseNumber();
  }


  changeBgColor(){
    this.b.bgColor='lightgreen';
  }
  
  changeColors(){
 
    this.name.nativeElement.style.backgroundColor='cyan';
    this.city.nativeElement.style.backgroundColor='yellow';
    
    this.name.nativeElement.style.color='red';
    this.city.nativeElement.style.color='magenta';
    
 
    this.e.nativeElement.style.backgroundColor='cyan';
    this.e.nativeElement.style.color='magenta';
  
  }

}
