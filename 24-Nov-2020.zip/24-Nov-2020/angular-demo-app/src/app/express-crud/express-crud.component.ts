import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-express-crud',
  templateUrl: './express-crud.component.html',
  styleUrls: ['./express-crud.component.css']
})
export class ExpressCRUDComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
