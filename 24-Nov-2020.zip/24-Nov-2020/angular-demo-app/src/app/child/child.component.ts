import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {


  message="Child Message";

  
  
  @Input()
  parentMessage="";


  @Output()
  childChnaged=new EventEmitter<string>();


  constructor() { }

  ngOnInit(): void {
  }



  sendMessageToParent(){
    console.log("Child Message :"+this.message);
    this.childChnaged.emit(this.message);

  }



}
