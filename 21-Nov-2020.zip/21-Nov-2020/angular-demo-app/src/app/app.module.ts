import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { HomeComponent } from './home/home.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { TodosComponent } from './todos/todos.component';
import { AlbumsComponent } from './albums/albums.component';
import { CommentsComponent } from './comments/comments.component';
import { PhotosComponent } from './photos/photos.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { UsersService } from './services/users.service';

@NgModule({
  declarations: [ //components,directives,pipes
    AppComponent,
    AngularBasicsComponent,
    AngularPipesComponent,
    TechnologiesComponent,
    HomeComponent,
    CaseStudyComponent,
    UsersComponent,
    PostsComponent,
    TodosComponent,
    AlbumsComponent,
    CommentsComponent,
    PhotosComponent,
    UsersListComponent,
    UsersTableComponent
  ],
  imports: [//modules
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
 // providers: [UsersService], //Before Angular 5
  providers: [], //Before Angular 5
 
 
 // bootstrap: [AppComponent,AngularBasicsComponent,TechnologiesComponent]//components
 bootstrap: [AppComponent]//components
})
export class AppModule { 
  constructor(){
    console.log("AppModule created...")
  }


}
