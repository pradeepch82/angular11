import { Component, OnInit } from '@angular/core';
import { CommentsService } from '../services/comments.service';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

 
  title='All Comments';

  comments:any;

  message='';


  constructor(private cs:CommentsService) {
    console.log("============CommentsComponent created======")
   }

  ngOnInit(): void {
    console.log("============CommentsComponent initialized======")
    this.getAllComments();
  }

  ngOnDestroy(): void {
    console.log("============CommentsComponent destroyed======")
    
  }


  getAllComments(){
     this.cs.getAllComments().subscribe(response=>this.comments=response,error=>this.message=error);
  }



}
