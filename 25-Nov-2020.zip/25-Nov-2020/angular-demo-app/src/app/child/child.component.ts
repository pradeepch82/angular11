import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {


  message="Child Message";

  
  
  @Input()
  parentMessage="";


  @Output()
  childChnaged=new EventEmitter<string>();


  constructor() { 
    console.log("############ ChildComponent  created #############");
  
  }
  
  ngOnInit(): void {
    console.log("############ ChildComponent  initialized #############");
    
  }
  
  ngOnDestroy(): void {
    console.log("############ ChildComponent  destroyed #############");
    }
  
  
  /*
    ngDoCheck() {
      console.log("############ ChildComponent  ngDoCheck #############");
    }
   */

    
    ngOnChanges() {
      console.log("############ ChildComponent  ngOnChanges #############");
    }
    
    ngAfterContentInit() {
      console.log("############ ChildComponent  ngAfterContentInit #############");
    }
    
    ngAfterContentChecked() {
      console.log("############ ChildComponent  ngAfterContentChecked #############");
    }
    
    ngAfterViewChecked() {
      console.log("############ ChildComponent  ngAfterViewChecked #############");
    }
    
    ngAfterViewInit() {
      console.log("############ ChildComponent  ngAfterViewInit #############");
    }
  


  sendMessageToParent(){
    console.log("Child Message :"+this.message);
    this.childChnaged.emit(this.message);

  }



}
