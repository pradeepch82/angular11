import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExpressService {


  private baseURL="http://localhost:3000/employees";

  constructor(private http:HttpClient) { 
    console.log("=========PostsService create ==============");
  }


  getAllEmployees():Observable<any>{
    return this.http.get(this.baseURL);
  }

  getEmployeeById(empId:number):Observable<any>{
    return this.http.get(this.baseURL+"/"+empId);
  }

 updateEmployeeById(empId:number,employee:any):Observable<any>{
    return this.http.put(this.baseURL+"/"+empId,employee);
  }
  
  addEmployee(employee:any):Observable<any>{
    return this.http.post(this.baseURL,employee);
  }
  
  deleteEmployeeId(empId:number):Observable<any>{
    return this.http.delete(this.baseURL+"/"+empId);
  }
 
}
