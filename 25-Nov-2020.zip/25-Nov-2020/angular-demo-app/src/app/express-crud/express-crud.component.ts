import { Component, OnInit } from '@angular/core';
import { ExpressService } from '../services/express.service';

@Component({
  selector: 'app-express-crud',
  templateUrl: './express-crud.component.html',
  styleUrls: ['./express-crud.component.css']
})
export class ExpressCRUDComponent implements OnInit {

  title='Express CRUD Application';

  employees:any;

  message='';


  employee=null;


  update=false;
  add=false;


 employeeId=0; 

  constructor(private es:ExpressService) {
    console.log("============ExpressCRUDComponent created======")
   }

  ngOnInit(): void {
    console.log("============ExpressCRUDComponent initialized======")
        
    console.log("============ExpressCRUDComponent initialized======");
    
    this.getAllEmployees();

  }

  ngOnDestroy(): void {
    console.log("============ExpressCRUDComponent destroyed======")
    
  }

  newEmployee(){
    this.employee={
      id:0,
      name:'',
      salary:0.0,
      doj:new Date()
    }
 this.update=true;
 this.add=false;


  }


  getAllEmployees(){
     this.es.getAllEmployees().subscribe(response=>this.employees=response,error=>this.message=error);
  }

  getEmployeeById(id){
    this.update=false;
    this.add=true;
 
    this.es.getEmployeeById(id).subscribe(response=>this.employee=response,error=>this.message=error);

  }
  updateEmployeeById(id){
    this.es.updateEmployeeById(id,this.employee).subscribe(response=>this.employees=response,error=>this.message=error);
    this.employee=null;
  }

  addEmployee(id){
    this.es.addEmployee(this.employee).subscribe(response=>this.employees=response,error=>this.message=error);
    this.employee=null;
  }



  deleteEmployeeById(id){
    this.es.deleteEmployeeId(id).subscribe(response=>this.employees=response,error=>this.message=error);
  }
}
