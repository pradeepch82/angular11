import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { HttpClientModule } from '@angular/common/http';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { HomeComponent } from './home/home.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { TodosComponent } from './todos/todos.component';
import { AlbumsComponent } from './albums/albums.component';
import { CommentsComponent } from './comments/comments.component';
import { PhotosComponent } from './photos/photos.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { UsersService } from './services/users.service';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { MustMatchDirective } from './directives/must-match.directive';
import { NestedComponent } from './nested/nested.component';
import { ViewChildComponent } from './view-child/view-child.component';
import { AddressModule } from './address/address.module';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { ExpressCRUDComponent } from './express-crud/express-crud.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { BgColorDirective } from './directives/bg-color.directive';
import { FgColorDirective } from './directives/fg-color.directive';
import { ShowDirective } from './directives/show.directive';
import { HideDirective } from './directives/hide.directive';
import { NumberComponent } from './number/number.component';
import { GenderPipe } from './pipes/gender.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
@NgModule({
  declarations: [ //components,directives,pipes
    AppComponent,
    AngularBasicsComponent,
    AngularPipesComponent,
    TechnologiesComponent,
    HomeComponent,
    CaseStudyComponent,
    UsersComponent,
    PostsComponent,
    TodosComponent,
    AlbumsComponent,
    CommentsComponent,
    PhotosComponent,
    UsersListComponent,
    UsersTableComponent,
    LoginComponent,
    RegisterComponent,
    MustMatchDirective,
    NestedComponent,
    ViewChildComponent,
    CustomDirectivesComponent,
    ExpressCRUDComponent,
    ParentComponent,
    ChildComponent,
    BgColorDirective,
    FgColorDirective,
    ShowDirective,
    HideDirective,
    NumberComponent,
    GenderPipe,
    OrderByPipe
  ],
  imports: [//modules //eagerly loaded
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    //AddressModule,
    Ng2SearchPipeModule
  ],
 // providers: [UsersService], //Before Angular 5
  providers: [], //Before Angular 5
 
 
 // bootstrap: [AppComponent,AngularBasicsComponent,TechnologiesComponent]//components
 bootstrap: [AppComponent]//components
})
export class AppModule { 
  constructor(){
    console.log("AppModule created...")
  }


}
