import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent implements OnInit,OnDestroy {



  title='Top 5 Technologies'; //string

  technologies=[
    {id:1,name:'Cloud',likes:0,dislikes:0},
    {id:2,name:'Angular',likes:0,dislikes:0},
    {id:3,name:'Spring Boot',likes:0,dislikes:0},
    {id:4,name:'React',likes:0,dislikes:0},
    {id:5,name:'Pivotal Cloud Foundry',likes:0,dislikes:0},
    ]; //array



    constructor() { 
      console.log("############ TechnologiesComponent  created #############");
  
    }
  
    ngOnInit(): void {
      console.log("############ TechnologiesComponent  initialized #############");
      
    }
  
    ngOnDestroy(): void {
      console.log("############ TechnologiesComponent  destroyed #############");
      }
  
    
    
      ngDoCheck() {
        console.log("############ TechnologiesComponent  ngDoCheck #############");
      }
  
      
      ngOnChanges() {
        console.log("############ TechnologiesComponent  ngOnChanges #############");
      }
      
      ngAfterContentInit() {
        console.log("############ TechnologiesComponent  ngAfterContentInit #############");
      }
      
      ngAfterContentChecked() {
        console.log("############ TechnologiesComponent  ngAfterContentChecked #############");
      }
      
      ngAfterViewChecked() {
        console.log("############ TechnologiesComponent  ngAfterViewChecked #############");
      }
      
      ngAfterViewInit() {
        console.log("############ TechnologiesComponent  ngAfterViewInit #############");
      }
    
  incrementLikes(t:any){
    t.likes++;
  }
  incrementDislikes(t:any){
    t.dislikes++;
  }

}
