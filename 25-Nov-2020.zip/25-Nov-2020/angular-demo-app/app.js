var express=require("express");
var cors=require("cors");


var server=express();


//enable json data parsing

server.use(express.static("./dist/angular-demo-app"));
server.use(express.json());
server.use(cors());



employees=[
    {id:101,name:'Pradeep Chinchole',salary:26000.55,doj:new Date()},
    {id:102,name:'Sachin Tendulkar',salary:12000.44,doj:new Date()},
    {id:103,name:'Rajesh Patil',salary:34567.99,doj:new Date()},
    {id:104,name:'Ankita Nag',salary:34566.77,doj:new Date()},
    {id:105,name:'Smita S',salary:12000.00,doj:new Date()}
];

//get all employees
server.get("/employees",function(request,response){
response.json(employees);
});

//get employee by id
server.get("/employees/:id",function(request,response){
    var employeeId=parseInt(request.params.id);
    var employee=employees.filter((e)=>e.id==employeeId)[0];
    response.json(employee);

});
    

//delete employee by id
server.delete("/employees/:id",function(request,response){
    var employeeId=parseInt(request.params.id);
    employees=employees.filter((e)=>e.id!=employeeId);
    response.json(employees);
});

//update employee by id
server.put("/employees/:id",function(request,response){
    var employeeId=parseInt(request.params.id);
    var emp=request.body;
    
    employees.forEach((e,i)=>{
        if(e.id==employeeId)
        employees[i]=emp;
    });
  
    response.json(employees);
});


//update employee by id
server.post("/employees",function(request,response){
    var emp=request.body;
        
    employees.push(emp);

    response.json(employees);
});




server.listen(3000,function(){
    console.log("Express Server listening on port 3000");
})
